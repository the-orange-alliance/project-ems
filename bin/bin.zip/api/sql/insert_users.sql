INSERT INTO "users" (user_id, username, password, permissions)
VALUES (0, "referee", "fgcref#1", "*");

INSERT INTO "users" (user_id, username, password, permissions)
VALUES (0, "scorekeeper", "fgcscores#1", "*");
