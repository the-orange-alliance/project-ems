import { Router } from 'express';
import { purgeAll } from '../db/Database.js';
const router = Router();
router.delete('/purge', async (req, res, next) => {
    try {
        await purgeAll();
        res.status(200).send({});
    }
    catch (e) {
        return next(e);
    }
});
export default router;
