import { isScheduleItemArray, isTeam } from '@toa-lib/models';
import { Router } from 'express';
import { deleteWhere, insertValue, selectAll, selectAllWhere, updateWhere } from '../db/Database.js';
import { validateBody } from '../middleware/BodyValidator.js';
import { DataNotFoundError } from '../util/Errors.js';
const router = Router();
router.get('/', async (req, res, next) => {
    try {
        const data = await selectAll('schedule');
        res.send(data);
    }
    catch (e) {
        return next(e);
    }
});
router.get('/:type', async (req, res, next) => {
    try {
        const data = await selectAllWhere('schedule', `type = '${req.params.type}'`);
        if (!data) {
            return next(DataNotFoundError);
        }
        res.send(data);
    }
    catch (e) {
        return next(e);
    }
});
router.post('/', validateBody(isScheduleItemArray), async (req, res, next) => {
    try {
        await insertValue('schedule', req.body);
        res.status(200).send({});
    }
    catch (e) {
        return next(e);
    }
});
router.delete('/:type', async (req, res, next) => {
    try {
        await deleteWhere('schedule', `type = "${req.params.type}"`);
        res.status(200).send({});
    }
    catch (e) {
        return next(e);
    }
});
router.patch('/:scheduleKey', validateBody(isTeam), async (req, res, next) => {
    try {
        await updateWhere('schedule', req.body, `scheduleKey = "${req.params.scheduleKey}"`);
        res.status(200).send({});
    }
    catch (e) {
        return next(e);
    }
});
export default router;
