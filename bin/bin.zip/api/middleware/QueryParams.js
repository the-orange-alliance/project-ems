import { isString } from '@toa-lib/models';
import { InvalidQueryError } from '../util/Errors.js';
export const requireParams = (params) => (req, res, next) => {
    for (const param of params) {
        if (!req.query[param] || !isString(req.query[param])) {
            return next(InvalidQueryError);
        }
    }
    return next();
};
