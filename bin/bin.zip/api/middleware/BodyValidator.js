import { BodyNotValidError, EmptyBodyError } from '../util/Errors.js';
export const validateBody = (t) => (req, res, next) => {
    if (!req.body)
        return next(EmptyBodyError);
    if (!t(req.body))
        return next(BodyNotValidError);
    return next();
};
