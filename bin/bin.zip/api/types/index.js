"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.isSQLError = exports.isApiError = exports.isBoolean = exports.isNumber = exports.isString = exports.isNonNullObject = void 0;
const isNonNullObject = (obj) => typeof obj === 'object' && obj !== null;
exports.isNonNullObject = isNonNullObject;
const isString = (str) => typeof str === 'string';
exports.isString = isString;
const isNumber = (num) => typeof num === 'number' && !isNaN(num);
exports.isNumber = isNumber;
const isBoolean = (bool) => typeof bool === 'boolean';
exports.isBoolean = isBoolean;
const isApiError = (err) => (0, exports.isNonNullObject)(err) && (0, exports.isNumber)(err.code) && (0, exports.isString)(err.message);
exports.isApiError = isApiError;
const isSQLError = (err) => (0, exports.isNonNullObject)(err) &&
    (0, exports.isNumber)(err.length) &&
    (0, exports.isString)(err.name) &&
    (0, exports.isString)(err.severity) &&
    (0, exports.isString)(err.code) &&
    (0, exports.isString)(err.position) &&
    (0, exports.isString)(err.file) &&
    (0, exports.isString)(err.line) &&
    (0, exports.isString)(err.routine);
exports.isSQLError = isSQLError;
