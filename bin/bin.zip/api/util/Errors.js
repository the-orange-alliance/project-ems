export const InvalidQueryError = {
    code: 400,
    message: 'Invalid query parameters.'
};
export const EmptyBodyError = {
    code: 400,
    message: 'Request body is empty.'
};
export const BodyNotValidError = {
    code: 400,
    message: 'Request body is not valid. Make sure required fields are present.'
};
export const UnauthorizedError = {
    code: 401,
    message: 'Please authenticate before using this route.'
};
export const AuthenticationError = {
    code: 500,
    message: 'Internal server error while trying to authenticate.'
};
export const AuthenticationNotLocalError = {
    code: 401,
    message: 'Your connection is not local for this authentication request.'
};
export const AuthenticationInvalidError = {
    code: 401,
    message: 'Invalid credentials. Please use a valid username/password combination.'
};
export const DataNotFoundError = {
    code: 500,
    message: 'Data requested was not found'
};
export const RouteNotFound = {
    code: 404,
    message: 'Route not found.'
};
