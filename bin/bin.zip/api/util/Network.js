const WHITELISTED_ADDRESSES = ['::1', '::ffff:127.0.0.1', '127.0.0.1'];
function isLocal(address) {
    return WHITELISTED_ADDRESSES.indexOf(address) !== -1;
}
export default isLocal;
