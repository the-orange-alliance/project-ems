"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.assignRooms = exports.initRooms = void 0;
const Match_1 = __importDefault(require("./Match"));
const roomsMap = new Map();
function initRooms(server) {
    const matchRoom = new Match_1.default(server);
    roomsMap.set(matchRoom.getName(), matchRoom);
}
exports.initRooms = initRooms;
function assignRooms(rooms, socket) {
    rooms.forEach((room) => {
        const r = roomsMap.get(room);
        if (!r)
            return;
        r.addClient(socket);
        socket.join(r.getName());
    });
}
exports.assignRooms = assignRooms;
