"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class Room {
    constructor(server, name) {
        this._server = server;
        this.clients = [];
        this.name = name;
    }
    addClient(socket) {
        this.clients.push(socket);
        this.initializeEvents(socket);
    }
    broadcast() {
        return this._server.to(this.getName());
    }
    getName() {
        return this.name;
    }
    get server() {
        return this._server;
    }
    set server(server) {
        this._server = server;
    }
}
exports.default = Room;
