"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const Room_1 = __importDefault(require("./Room"));
class Match extends Room_1.default {
    constructor(server) {
        super(server, 'match');
    }
    initializeEvents(socket) {
        socket.on('match:prestart', (matchKey) => {
            console.log(`prestarting ${matchKey}`);
        });
    }
}
exports.default = Match;
