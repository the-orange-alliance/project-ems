"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importStar(require("express"));
const http_1 = require("http");
const socket_io_1 = require("socket.io");
const cors_1 = __importDefault(require("cors"));
const body_parser_1 = require("body-parser");
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
const server_1 = require("@toa-lib/server");
const Logger_1 = __importDefault(require("./util/Logger"));
const Rooms_1 = require("./rooms/Rooms");
// Setup our environment
server_1.environment.loadAndSetDefaults();
// Bind socket.io to express to our http server
const app = (0, express_1.default)();
const server = (0, http_1.createServer)(app);
const io = new socket_io_1.Server(server);
// Config middleware
app.use((0, cors_1.default)({ credentials: true }));
app.use((0, express_1.json)());
app.use((0, body_parser_1.urlencoded)({ extended: false }));
io.use((socket, next) => {
    if (socket.handshake.query && socket.handshake.query.token) {
        jsonwebtoken_1.default.verify(socket.handshake.query.token.toString(), server_1.environment.get().jwtSecret, (err, decoded) => {
            if (err) {
                return next(new Error("Authentication Error"));
            }
            else {
                socket.decoded = decoded;
                next();
            }
        });
    }
    else {
        next(new Error("Authentication Error: no query token present"));
    }
});
io.on("connection", (socket) => {
    const user = socket.decoded;
    Logger_1.default.info(`user '${user.username}' connected and verified`);
    socket.on('rooms', (rooms) => {
        Logger_1.default.info(`user ${user.username} joining rooms ${rooms}`);
        (0, Rooms_1.assignRooms)(rooms, socket);
    });
    socket.on("disconnect", () => {
        Logger_1.default.info(`user ${user.username} disconnected`);
    });
});
server.listen({
    host: server_1.environment.get().serviceHost,
    port: server_1.environment.get().servicePort
}, () => {
    Logger_1.default.info(`[${server_1.environment.get().nodeEnv.charAt(0).toUpperCase()}][${server_1.environment
        .get()
        .serviceName.toUpperCase()}] Server started on ${server_1.environment.get().serviceHost}:${server_1.environment.get().servicePort}`);
    (0, Rooms_1.initRooms)(io);
});
