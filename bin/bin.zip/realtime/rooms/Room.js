export default class Room {
    clients;
    name;
    _server;
    constructor(server, name) {
        this._server = server;
        this.clients = [];
        this.name = name;
    }
    addClient(socket) {
        this.clients.push(socket);
    }
    removeClient(socket) {
        if (this.clients.indexOf(socket) > -1) {
            this.clients.splice(this.clients.indexOf(socket), 1);
        }
    }
    broadcast() {
        return this._server.in(this.getName());
    }
    getName() {
        return this.name;
    }
    get server() {
        return this._server;
    }
    set server(server) {
        this._server = server;
    }
}
