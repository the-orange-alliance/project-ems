import FCS from "./FCS.js";
import Match from "./Match.js";
const roomsMap = new Map();
export function initRooms(server) {
    const matchRoom = new Match(server);
    const fcsRoom = new FCS(server);
    roomsMap.set(matchRoom.getName(), matchRoom);
    roomsMap.set(fcsRoom.getName(), fcsRoom);
}
export function assignRooms(rooms, socket) {
    rooms.forEach((room) => {
        const r = roomsMap.get(room);
        if (!r)
            return;
        socket.join(r.getName());
        r.addClient(socket);
        r.initializeEvents(socket);
    });
}
export function leaveRooms(socket) {
    for (const room of roomsMap.values()) {
        room.removeClient(socket);
    }
}
