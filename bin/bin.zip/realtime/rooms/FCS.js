import Room from "./Room.js";
export default class FCS extends Room {
    constructor(server) {
        super(server, "fcs");
    }
    initializeEvents(socket) {
        socket.on("fcs:update", (update) => {
            this.broadcast().emit("fcs:update", update);
        });
    }
}
