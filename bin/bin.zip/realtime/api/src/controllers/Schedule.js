"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const models_1 = require("@toa-lib/models");
const express_1 = require("express");
const Database_1 = require("../db/Database");
const BodyValidator_1 = require("../middleware/BodyValidator");
const Errors_1 = require("../util/Errors");
const router = (0, express_1.Router)();
router.get('/', (req, res, next) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const data = yield (0, Database_1.selectAll)('schedule');
        res.send(data);
    }
    catch (e) {
        return next(e);
    }
}));
router.get('/:type', (req, res, next) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const data = yield (0, Database_1.selectAllWhere)('schedule', `type = '${req.params.type}'`);
        if (!data) {
            return next(Errors_1.DataNotFoundError);
        }
        res.send(data);
    }
    catch (e) {
        return next(e);
    }
}));
router.post('/', (0, BodyValidator_1.validateBody)(models_1.isScheduleItemArray), (req, res, next) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        yield (0, Database_1.insertValue)('schedule', req.body);
        res.status(200).send({});
    }
    catch (e) {
        return next(e);
    }
}));
router.patch('/:scheduleKey', (0, BodyValidator_1.validateBody)(models_1.isTeam), (req, res, next) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        yield (0, Database_1.updateWhere)('schedule', req.body, `scheduleKey = "${req.params.scheduleKey}"`);
        res.status(200).send({});
    }
    catch (e) {
        return next(e);
    }
}));
exports.default = router;
