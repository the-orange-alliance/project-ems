"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const models_1 = require("@toa-lib/models");
const express_1 = require("express");
const Database_1 = require("../db/Database");
const BodyValidator_1 = require("../middleware/BodyValidator");
const Errors_1 = require("../util/Errors");
const path_1 = require("path");
const promises_1 = require("fs/promises");
const server_1 = require("@toa-lib/server");
const Logger_1 = __importDefault(require("../util/Logger"));
const router = (0, express_1.Router)();
router.get('/', (req, res, next) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        if (req.query.tournamentLevel) {
            const data = yield (0, Database_1.selectAllWhere)('match', `tournamentLevel = ${req.query.tournamentLevel}`);
            res.send(data);
        }
        else if (req.query.type) {
            const data = yield (0, Database_1.selectAllWhere)('match', `tournamentLevel = ${(0, models_1.getTournamentLevelFromType)(req.query.type)}`);
            res.send(data);
        }
        else {
            const data = yield (0, Database_1.selectAll)('match');
            res.send(data);
        }
    }
    catch (e) {
        return next(e);
    }
}));
router.get('/participants', (req, res, next) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        if (req.query.matchKeyPartial) {
            const data = yield (0, Database_1.selectAllWhere)('match_participant', `matchKey LIKE "${req.query.matchKeyPartial}%"`);
            res.send(data);
        }
    }
    catch (e) {
        return next(e);
    }
}));
router.get('/:matchKey', (req, res, next) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const data = yield (0, Database_1.selectAllWhere)('match', `matchKey = ${req.params.matchKey}`);
        if (!data) {
            return next(Errors_1.DataNotFoundError);
        }
        res.send(data);
    }
    catch (e) {
        return next(e);
    }
}));
router.post('/', (0, BodyValidator_1.validateBody)(models_1.isMatchArray), (req, res, next) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const pureMatches = req.body.map((m) => (Object.assign({}, m)));
        for (const match of pureMatches)
            delete match.participants;
        const participants = req.body
            .map((match) => match.participants || [])
            .flat();
        const details = req.body.map((match) => ({
            matchKey: match.matchKey,
            matchDetailKey: match.matchDetailKey
        }));
        yield (0, Database_1.insertValue)('match', pureMatches);
        yield (0, Database_1.insertValue)('match_participant', participants);
        yield (0, Database_1.insertValue)('match_detail', details);
        res.status(200).send({});
    }
    catch (e) {
        return next(e);
    }
}));
// router.patch(
//   '/:matchKey',
//   validateBody(isTeam),
//   async (req: Request, res: Response, next: NextFunction) => {
//     try {
//       await updateWhere(
//         'match',
//         req.body,
//         `matchKey = "${req.params.matchKey}"`
//       );
//       res.status(200).send({});
//     } catch (e) {
//       return next(e);
//     }
//   }
// );
/** SPECIAL ROUTES */
router.post('/create', (0, BodyValidator_1.validateBody)(models_1.isMatchMakerRequest), (req, res, next) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const matchMakerPath = (0, path_1.join)(__dirname, '../../bin/MatchMaker.exe');
        // First we have to make the teamlist for matchmaker
        const config = req.body;
        const teamsPath = (0, path_1.join)((0, server_1.getAppData)('ems'), `${config.type}-teams.txt`);
        const contents = config.teamKeys.toString().replace(/,/g, '\n');
        yield (0, promises_1.writeFile)(teamsPath, contents);
        Logger_1.default.info(`wrote teams file at ${teamsPath}`);
        const matchMakerArgs = [
            '-l',
            teamsPath,
            '-t',
            config.teamsParticipating.toString(),
            '-r',
            config.matchesPerTeam.toString(),
            '-a',
            config.teamsPerAlliance.toString(),
            (0, server_1.getArgFromQualityStr)(config.quality),
            '-s',
            '-o'
        ];
        Logger_1.default.info(`executing matchmaker (${matchMakerPath}) with arguments ${matchMakerArgs.toString()}`);
        const matches = yield (0, server_1.executeMatchMaker)(matchMakerPath, matchMakerArgs, config);
        Logger_1.default.info('mathmaker complete - sending results');
        res.send(matches);
    }
    catch (e) {
        return next(e);
    }
}));
exports.default = router;
