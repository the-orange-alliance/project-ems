"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const server_1 = require("@toa-lib/server");
const models_1 = require("@toa-lib/models");
const express_1 = require("express");
const passport_1 = __importDefault(require("passport"));
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
const Errors_1 = require("../util/Errors");
const QueryParams_1 = require("../middleware/QueryParams");
const BodyValidator_1 = require("../middleware/BodyValidator");
const Network_1 = __importDefault(require("../util/Network"));
const Database_1 = require("../db/Database");
const router = (0, express_1.Router)();
/** GET method that will return the current authentication status of the user. */
router.get('/', (0, QueryParams_1.requireParams)(['token']), (req, res, next) => __awaiter(void 0, void 0, void 0, function* () {
    jsonwebtoken_1.default.verify(req.query.token, 'changeit', (err, decoded) => {
        if (err)
            next(Errors_1.AuthenticationError);
        res.send(decoded);
    });
}));
/** POST method that will attempt to login the user based on their credentials. */
router.post('/login', (0, BodyValidator_1.validateBody)(models_1.isUserLogin), (req, res, next) => {
    passport_1.default.authenticate('local', { session: false }, (err, user, info) => {
        if (err || !user) {
            return next(Errors_1.AuthenticationInvalidError);
        }
        else {
            // Do one final check - if they're using the admin user, validate they're local.
            if (user.username === models_1.DEFAULT_ADMIN_USERNAME &&
                (0, Network_1.default)(req.socket.remoteAddress || '')) {
                req.login(user, { session: false }, (err) => {
                    if (err) {
                        return next(err);
                    }
                    const userLogin = Object.assign(Object.assign({}, user), { token: '' });
                    userLogin.token = jsonwebtoken_1.default.sign(user, server_1.environment.get().jwtSecret);
                    return res.json(userLogin);
                });
            }
            else {
                return next(Errors_1.AuthenticationNotLocalError);
            }
        }
    })(req, res, next);
});
router.get('/logout', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    req.logout({}, () => {
        res.send({ message: 'successfully logged out' });
    });
}));
router.get('/users', (req, res, next) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const data = yield (0, Database_1.selectAll)('users');
        res.send(data);
    }
    catch (e) {
        return next(e);
    }
}));
router.get('/setup', (req, res, next) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        yield (0, Database_1.setupUsers)();
        res.status(200).send({});
    }
    catch (e) {
        return next(e);
    }
}));
exports.default = router;
