"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const models_1 = require("@toa-lib/models");
const express_1 = require("express");
const Database_1 = require("../db/Database");
const BodyValidator_1 = require("../middleware/BodyValidator");
const Errors_1 = require("../util/Errors");
const router = (0, express_1.Router)();
router.get('/', (req, res, next) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const data = yield (0, Database_1.selectAll)('team');
        res.send(data);
    }
    catch (e) {
        return next(e);
    }
}));
router.get('/:teamKey', (req, res, next) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const data = yield (0, Database_1.selectAllWhere)('team', `teamKey = ${req.params.teamKey}`);
        if (!data) {
            return next(Errors_1.DataNotFoundError);
        }
        res.send(data);
    }
    catch (e) {
        return next(e);
    }
}));
router.post('/', (0, BodyValidator_1.validateBody)(models_1.isTeamArray), (req, res, next) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        yield (0, Database_1.insertValue)('team', req.body);
        res.status(200).send({});
    }
    catch (e) {
        return next(e);
    }
}));
router.patch('/:teamKey', (0, BodyValidator_1.validateBody)(models_1.isTeam), (req, res, next) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        yield (0, Database_1.updateWhere)('team', req.body, `teamKey = "${req.params.teamKey}"`);
        res.status(200).send({});
    }
    catch (e) {
        return next(e);
    }
}));
exports.default = router;
