"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importStar(require("express"));
const http_1 = require("http");
const cors_1 = __importDefault(require("cors"));
const body_parser_1 = require("body-parser");
const passport_1 = __importDefault(require("passport"));
const server_1 = require("@toa-lib/server");
const Admin_1 = __importDefault(require("./controllers/Admin"));
const Authentication_1 = __importDefault(require("./controllers/Authentication"));
const Event_1 = __importDefault(require("./controllers/Event"));
const Team_1 = __importDefault(require("./controllers/Team"));
const Storage_1 = __importDefault(require("./controllers/Storage"));
const Schedule_1 = __importDefault(require("./controllers/Schedule"));
const Match_1 = __importDefault(require("./controllers/Match"));
const ErrorHandler_1 = require("./middleware/ErrorHandler");
const Logger_1 = __importDefault(require("./util/Logger"));
const Database_1 = require("./db/Database");
// Setup our environment
server_1.environment.loadAndSetDefaults();
// App setup - if any of these fail the server should exit.
try {
    (0, Database_1.initDatabase)();
}
catch (e) {
    Logger_1.default.error(e);
    process.exit(1);
}
// Bind express to our http server
const app = (0, express_1.default)();
const server = (0, http_1.createServer)(app);
// Setup and config express middleware
app.use((0, cors_1.default)({ credentials: true, origin: 'http://localhost:5173' }));
app.use((0, express_1.json)());
app.use((0, body_parser_1.urlencoded)({ extended: false }));
app.use(passport_1.default.initialize());
// Setup passport config
passport_1.default.use((0, server_1.jwtStrategy)(server_1.environment.get().jwtSecret));
passport_1.default.use((0, server_1.localStrategy)());
// Define our route controllers
app.use('/admin', Admin_1.default);
app.use('/auth', Authentication_1.default);
app.use('/event', Event_1.default);
app.use('/teams', Team_1.default);
app.use('/storage', Storage_1.default);
app.use('/schedule', Schedule_1.default);
app.use('/match', Match_1.default);
// Define root/testing paths
app.get('/', server_1.requireAuth, (req, res) => {
    res.send(req.headers);
});
// Define error middleware
app.use(ErrorHandler_1.handleErrors);
app.use(ErrorHandler_1.handleCatchAll);
// Passport serizliation
passport_1.default.serializeUser((user, cb) => {
    console.log('serialize user', user);
    cb(null, user.id);
});
passport_1.default.deserializeUser((id, cb) => {
    console.log('deserialize user', id);
    cb(null, { id: 0, user: 'admin' });
});
// Start the server
server.listen({
    host: server_1.environment.get().serviceHost,
    port: server_1.environment.get().servicePort
}, () => Logger_1.default.info(`[${server_1.environment.get().nodeEnv.charAt(0).toUpperCase()}][${server_1.environment
    .get()
    .serviceName.toUpperCase()}] Server started on ${server_1.environment.get().serviceHost}:${server_1.environment.get().servicePort}`));
