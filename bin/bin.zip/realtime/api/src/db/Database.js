"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.updateWhere = exports.insertValue = exports.selectAllWhere = exports.selectAll = exports.purgeAll = exports.createEventGameSpecifics = exports.createEventBase = exports.insertUsers = exports.setupUsers = exports.initDatabase = void 0;
const promised_sqlite3_1 = require("promised-sqlite3");
const server_1 = require("@toa-lib/server");
const models_1 = require("@toa-lib/models");
const promises_1 = require("node:fs/promises");
const path_1 = require("path");
const db = new promised_sqlite3_1.PromisedDatabase();
function initDatabase() {
    return __awaiter(this, void 0, void 0, function* () {
        // Make sure our appdata path is created
        try {
            yield (0, promises_1.mkdir)((0, server_1.getAppData)('ems'), { recursive: true });
            const dbFile = server_1.environment.isProd() ? 'prod.db' : 'dev.db';
            db.open((0, server_1.getAppData)('ems') + path_1.sep + dbFile);
        }
        catch (e) {
            throw e;
        }
    });
}
exports.initDatabase = initDatabase;
function setupUsers() {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const createQuery = yield getQueryFromFile('create_users.sql');
            yield db.exec(createQuery);
            return;
        }
        catch (e) {
            throw e;
        }
    });
}
exports.setupUsers = setupUsers;
function insertUsers() {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const insertQuery = yield getQueryFromFile('insert_users.sql');
            yield db.exec(insertQuery);
            return;
        }
        catch (e) {
            throw e;
        }
    });
}
exports.insertUsers = insertUsers;
function createEventBase() {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const createQuery = yield getQueryFromFile('create_event.sql');
            yield db.exec(createQuery);
            return;
        }
        catch (e) {
            throw e;
        }
    });
}
exports.createEventBase = createEventBase;
function createEventGameSpecifics() {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const createQuery = yield getQueryFromFile('details/fgc_2022.sql');
            yield db.exec(createQuery);
            return;
        }
        catch (e) {
            throw e;
        }
    });
}
exports.createEventGameSpecifics = createEventGameSpecifics;
function purgeAll() {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const purgeQuery = yield getQueryFromFile('purge.sql');
            yield db.exec(purgeQuery);
            return;
        }
        catch (e) {
            throw e;
        }
    });
}
exports.purgeAll = purgeAll;
function selectAll(table) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            return yield db.all(`SELECT * FROM ${table};`);
        }
        catch (e) {
            throw new models_1.ApiDatabaseError(table, e);
        }
    });
}
exports.selectAll = selectAll;
function selectAllWhere(table, where) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            return yield db.all(`SELECT * FROM ${table} WHERE ${where};`);
        }
        catch (e) {
            throw new models_1.ApiDatabaseError(table, e);
        }
    });
}
exports.selectAllWhere = selectAllWhere;
function insertValue(table, values) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const columns = getColumns(values);
            const query = `INSERT INTO ${table} (${Array.from(columns).toString()}) VALUES ${getValuesString(columns, values)}`;
            return yield db.all(query);
        }
        catch (e) {
            throw new models_1.ApiDatabaseError(table, e);
        }
    });
}
exports.insertValue = insertValue;
function updateWhere(table, value, where) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const update = getUpdateString(value);
            const query = `UPDATE ${table} SET ${update} WHERE ${where};`;
            return yield db.all(query);
        }
        catch (e) {
            throw new models_1.ApiDatabaseError(table, e);
        }
    });
}
exports.updateWhere = updateWhere;
/**
 * Internal async function to get a query from the sql/ directory in the api folder.
 * @param filePath - String that is the file's name or path if sub-folders exist.
 * @returns Promise<string> of the file's contents as an sql-safe string.
 */
function getQueryFromFile(filePath) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const fullPath = (0, path_1.join)(__dirname, '../../sql/' + filePath);
            const data = yield (0, promises_1.readFile)(fullPath);
            return data
                .toString()
                .replace(/\n/g, '')
                .replace(/\t/g, '')
                .replace(/\r/g, '');
        }
        catch (e) {
            throw e;
        }
    });
}
function getUpdateString(value) {
    return Object.keys(value)
        .map((key) => `"${key}" = "${value[key]}"`)
        .toString();
}
function getValuesString(columns, values) {
    return values
        .map((obj) => {
        const valuesStr = Array.from(columns)
            .map((col) => {
            if (typeof obj[col] === 'undefined') {
                return 'null';
            }
            else if (typeof obj[col] === 'string') {
                return `'${obj[col]}'`;
            }
            else {
                return obj[col];
            }
        })
            .toString();
        return `(${valuesStr})`;
    })
        .toString();
}
function getColumns(values) {
    const keys = new Set();
    values.map((obj) => {
        Object.keys(obj).map((key) => keys.add(key));
    });
    return keys;
}
