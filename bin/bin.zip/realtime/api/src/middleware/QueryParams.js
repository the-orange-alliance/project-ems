"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.requireParams = void 0;
const models_1 = require("@toa-lib/models");
const Errors_1 = require("../util/Errors");
const requireParams = (params) => (req, res, next) => {
    for (const param of params) {
        if (!req.query[param] || !(0, models_1.isString)(req.query[param])) {
            return next(Errors_1.InvalidQueryError);
        }
    }
    return next();
};
exports.requireParams = requireParams;
