"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.handleCatchAll = exports.handleErrors = void 0;
const Logger_1 = __importDefault(require("../util/Logger"));
const models_1 = require("@toa-lib/models");
const Errors_1 = require("../util/Errors");
const handleErrors = (error, req, res, next) => {
    if (error instanceof models_1.ApiDatabaseError) {
        Logger_1.default.error(`[500] ${error.message} (${req.method} - ${req.originalUrl})`);
        res.status(500).send(toApiError(error));
    }
    else if ((0, models_1.isApiError)(error) && error.code <= 500) {
        Logger_1.default.error(`[${error.code}] ${error.message} (${req.method} - ${req.originalUrl})`);
        res.status(error.code).send(JSON.stringify(error));
    }
    else {
        Logger_1.default.error(`${JSON.stringify(error)} (${req.method} - ${req.originalUrl})`);
        res.status(500).send(JSON.stringify(error));
    }
};
exports.handleErrors = handleErrors;
const handleCatchAll = (req, res, next) => {
    Logger_1.default.warn(`Route not found (${req.originalUrl})`);
    res.status(404).send(JSON.stringify(Errors_1.RouteNotFound));
};
exports.handleCatchAll = handleCatchAll;
function toApiError(err) {
    return { code: 500, message: err.message };
}
