"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.validateBody = void 0;
const Errors_1 = require("../util/Errors");
const validateBody = (t) => (req, res, next) => {
    if (!req.body)
        return next(Errors_1.EmptyBodyError);
    if (!t(req.body))
        return next(Errors_1.BodyNotValidError);
    return next();
};
exports.validateBody = validateBody;
