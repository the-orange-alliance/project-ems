"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.RouteNotFound = exports.DataNotFoundError = exports.AuthenticationInvalidError = exports.AuthenticationNotLocalError = exports.AuthenticationError = exports.UnauthorizedError = exports.BodyNotValidError = exports.EmptyBodyError = exports.InvalidQueryError = void 0;
exports.InvalidQueryError = {
    code: 400,
    message: 'Invalid query parameters.'
};
exports.EmptyBodyError = {
    code: 400,
    message: 'Request body is empty.'
};
exports.BodyNotValidError = {
    code: 400,
    message: 'Request body is not valid. Make sure required fields are present.'
};
exports.UnauthorizedError = {
    code: 401,
    message: 'Please authenticate before using this route.'
};
exports.AuthenticationError = {
    code: 500,
    message: 'Internal server error while trying to authenticate.'
};
exports.AuthenticationNotLocalError = {
    code: 401,
    message: 'Your connection is not local for this authentication request.'
};
exports.AuthenticationInvalidError = {
    code: 401,
    message: 'Invalid credentials. Please use a valid username/password combination.'
};
exports.DataNotFoundError = {
    code: 500,
    message: 'Data requested was not found'
};
exports.RouteNotFound = {
    code: 404,
    message: 'Route not found.'
};
