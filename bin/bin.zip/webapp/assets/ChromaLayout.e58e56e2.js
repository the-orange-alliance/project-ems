import{e as a,j as s}from"./index.234ad9b5.js";import{B as o,C as e}from"./CssBaseline.0bf0e5f8.js";const i=({children:r})=>a(o,{children:[s(e,{}),s(o,{children:r})]});export{i as C};
