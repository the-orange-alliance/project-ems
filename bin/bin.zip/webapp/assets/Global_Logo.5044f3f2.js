const s="/assets/global-bg.ce8cc031.png",a="/assets/Global_Logo.fa22a2db.png";export{s as F,a};
