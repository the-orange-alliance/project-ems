import{e as a,j as s}from"./index.624a2ed8.js";import{B as o,C as e}from"./CssBaseline.9bac7c94.js";const i=({children:r})=>a(o,{children:[s(e,{}),s(o,{children:r})]});export{i as C};
